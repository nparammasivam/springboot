package com.healthcare.springboot.web.service;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.healthcare.springboot.web.model.Product;

public interface ProductRepository extends JpaRepository<Product, Integer>{
	List<Product> findByUser(String product);	
	
	@Query("SELECT p FROM Product p WHERE (lower(p.desc) LIKE %?1%) or (lower(p.name) LIKE %?1%) or (lower(p.type) LIKE %?1%)")
	//@Query(value="SELECT * FROM PRODUCT WHERE desc=?1", nativeQuery=true)
	List<Product> findByDisease(String product);
}
