insert into PRODUCT
values (10001, 'Colon Health', 'Apple','Fruit','siva');
insert into PRODUCT
values (10002, 'Cold', 'Tulsi', 'Herb','siva');
insert into PRODUCT
values (10003, 'Throat Infection', 'Athimathuram','Herb', 'siva');
insert into PRODUCT
values (10004, 'Energy', 'Orange','Fruit','siva');
insert into PRODUCT
values (10005, 'Cold', 'Thuthuvalai', 'Herb','siva');
insert into PRODUCT
values (10006, 'Throat Infection', 'Dry Ginger','Herb', 'siva');
insert into PRODUCT
values (10007, 'Lowering cholesterol and blood pressure', 'Garlic','Fruit','siva');
insert into PRODUCT
values (10008, 'Asthma', 'Gingko', 'Herb','siva');
insert into PRODUCT
values (10009, 'Goldenseal', 'Diarrhea','Herb', 'siva');
insert into PRODUCT
values (10010, 'Heart disease', 'Pomegranates','Fruit','siva');
insert into PRODUCT
values (10011, 'Vitamin Powerhouse', 'Grapes','Fruit','siva');