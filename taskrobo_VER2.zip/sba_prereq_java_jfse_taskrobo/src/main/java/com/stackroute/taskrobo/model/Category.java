package com.stackroute.taskrobo.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

/*
 * The class "Category" will be acting as the data model for the Category Table in the database.
 * Please note that this class is annotated with @Entity annotation.
 */
@Entity
public class Category {
    /* categoryTitle is annotated with @Id */
	@Id
    private String categoryTitle;
    
	/* tasks is annotated with @OneToMany */
	@OneToMany
	@JoinColumn(name ="taskId")
    private List<Task> tasks;
    
    /* Write parameterized constructor */

    /* Add getter and setter methods for all the properties */

    public Category() {
    	super();
    }
    
    public Category( String categoryTitle, List<Task> tasks) {
    	super();
    	this.categoryTitle = categoryTitle;
    	this.tasks = tasks;
    }
    
    public String getCategoryTitle() {
		return categoryTitle;
	}

	public void setCategoryTitle(String categoryTitle) {
		this.categoryTitle = categoryTitle;
	}

	public List<Task> getTasks() {
		return tasks;
	}

	public void setTasks(List<Task> tasks) {
		this.tasks = tasks;
	}


	
}
