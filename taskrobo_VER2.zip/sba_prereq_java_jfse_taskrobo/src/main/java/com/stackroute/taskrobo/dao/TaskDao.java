package com.stackroute.taskrobo.dao;

import com.stackroute.taskrobo.model.Task;

import java.util.List;


public interface TaskDao {

    boolean saveTask(Task task);

    boolean deleteTask(int taskId);

    List<Task> getAllTasks();

    Task getTaskById(int taskId);

    boolean updateTask(Task task);

}
