package com.stackroute.taskrobo.dao;

import com.stackroute.taskrobo.model.Category;
import com.stackroute.taskrobo.model.Task;

import java.util.List;

public interface CategoryDao {
    boolean saveCategory(Category category);

    boolean deleteCategory(String categoryTitle);

    List<Category> getAllCategories();

    Category getCategoryByTitle(String categoryTitle);

	List<Task> getAllTasks(String categoryTitle);

}
