package com.stackroute.taskrobo.service;

import com.stackroute.taskrobo.dao.CategoryDao;
import com.stackroute.taskrobo.exception.CategoryAlreadyExistException;
import com.stackroute.taskrobo.exception.CategoryDoesNotExistException;
import com.stackroute.taskrobo.model.Category;
import com.stackroute.taskrobo.model.Task;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/*
 * Service classes are used here to implement additional business logic/validation
 * This class has to be annotated with @Service annotation.
 */

@Service
@PropertySource("classpath:application.properties")
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	private CategoryDao categoryDao;

	public void setCategoryDao(CategoryDao categoryDao) {
		this.categoryDao = categoryDao;
	}
	
	/*
	 * Do not hardcode exception message. Get it from application.properties using
	 * environment variables.
	 */
	@Autowired
	private Environment environment;

	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

	

	/*
	 * Constructor based Autowiring should be implemented for the CategoryDao and
	 * Environment.Please note that we should not create any object using the new
	 * keyword.
	 */

	/*
	 * This method should be used to save a new category.
	 */

	@Override
	@Transactional
	public boolean saveCategory(Category category) throws CategoryAlreadyExistException {
		if (category != null) {
			this.categoryDao.saveCategory(category);
			return true;
		} else {
			return false;
		}
	}

	/*
	 * This method should be used to get a category by categoryTitle.
	 */

	@Override
	@Transactional
	public Category getCategoryByTitle(String categoryTitle) throws CategoryDoesNotExistException {
		if (categoryTitle != null) {
			return this.categoryDao.getCategoryByTitle(categoryTitle);
		} else {
			return null;
		}
	}

	/*
	 * This method should be used to get all the tasks for particular Category.
	 */
	@Override
	@Transactional
	public List<Task> getAllTasks(String categoryTitle) throws CategoryDoesNotExistException {
		if (categoryTitle != null) {
			return this.categoryDao.getAllTasks(categoryTitle);
		} else {
			return null;
		}
	}

	/*
	 * This method should be used to get all the categories.
	 */

	@Override
	@Transactional
	public List<Category> getAllCategories() {
			return this.categoryDao.getAllCategories();
	}

	/* This method should be used to delete an existing category. */

	@Override
	@Transactional
	public boolean deleteCategory(String categoryTitle) throws CategoryDoesNotExistException {
		if (categoryTitle != null) {
			return this.categoryDao.deleteCategory(categoryTitle);
		} else {
			return false;
		}
	}

}