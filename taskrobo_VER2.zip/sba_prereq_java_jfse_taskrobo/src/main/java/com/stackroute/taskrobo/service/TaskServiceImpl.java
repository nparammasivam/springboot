package com.stackroute.taskrobo.service;

import com.stackroute.taskrobo.dao.TaskDao;
import com.stackroute.taskrobo.exception.TaskAlreadyExistException;
import com.stackroute.taskrobo.exception.TaskDoesNotExistException;
import com.stackroute.taskrobo.model.Task;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/*
 * Service classes are used here to implement additional business logic/validation
 * This class has to be annotated with @Service annotation.
 */
@Service
@PropertySource("classpath:application.properties")
public class TaskServiceImpl implements TaskService {
	@Autowired
    private TaskDao taskDAO;
	
	public void setTaskDAO(TaskDao taskDAO) {
		this.taskDAO = taskDAO;
	}
	
    /* Do not hardcode exception message. Get it from application.properties using environment variables. */
    @Autowired
	private Environment environment;

	public void setEnvironment(Environment environment) {
		this.environment = environment;
	}

    public TaskServiceImpl() {
    }

    /*
     * Constructor based Autowiring should be implemented for the TaskDao and
     * Environment.Please note that we should not create any object using the new
     * keyword.
     */

    /*
     * This method should be used to save a new task.
     */
    @Override
    @Transactional
    public boolean saveTask(Task task) throws TaskAlreadyExistException {
    	if (task != null) {
			this.taskDAO.saveTask(task);
			return true;
		} else {
			return false;
		}
    }

    /*
     * This method should be used to update a existing task.
     */

    @Override
    @Transactional
    public boolean updateTask(Task task) throws TaskDoesNotExistException {
    	if (task != null) {
			this.taskDAO.updateTask(task);
			return true;
		} else {
			return false;
		}
    }


    /*
     * This method should be used to get a task by taskId.
     */

    @Override
    @Transactional
    public Task getTaskById(int taskId) throws TaskDoesNotExistException {
    	if (taskId > 0) {
			return this.taskDAO.getTaskById(taskId);
		} else {
			return null;
		}
    }

    /*
     * This method should be used to get all the tasks.
     */

    @Override
    @Transactional
    public List<Task> getAllTasks() {
    	return this.taskDAO.getAllTasks();
    }


    /* This method should be used to delete an existing task. */
    @Override
    @Transactional
    public boolean deleteTask(int taskId) throws TaskDoesNotExistException {
    	if (taskId > 0) {
			return this.taskDAO.deleteTask(taskId);
		} else {
			return false;
		}
    }

	
}
