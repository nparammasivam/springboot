package com.stackroute.taskrobo.dao;

import com.stackroute.taskrobo.model.Category;
import com.stackroute.taskrobo.model.Task;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

import javax.transaction.Transactional;

/*
 * This class is implementing the CategoryDao interface. This class has to be annotated with following annotation
 * @Repository - is an annotation that marks the specific class as a Data Access Object, thus
 * 				 clarifying it's role.
 * @Transactional - The transactional annotation itself defines the scope of a single database
 * 					transaction. The database transaction happens inside the scope of a persistence
 * 					context.
 * */
@Repository
@Transactional
public class CategoryDaoImpl implements CategoryDao {
	private static final Logger logger = LoggerFactory.getLogger(CategoryDaoImpl.class);
	
	
	@Autowired
    private SessionFactory sessionFactory;

    public CategoryDaoImpl() {
    }

    /*
     * Constructor based Autowiring should be implemented for the SessionFactory.
     * Please note that we should not create any object using the new
     * keyword.
     */

    /*
     * Save the category in the database(category) table.
     */

    @Override
    public boolean saveCategory(Category category) {
    	if(category != null) {
    		logger.info("Category saved successfully, Category Details="+category);
    		return (boolean) sessionFactory.getCurrentSession().save(category);    		
    	} else  {
    		return false;
    	}
    }

    /*
     * Remove the category from the database(category) table.
     */

    @Override
    public boolean deleteCategory(String categoryTitle) {
    	if(categoryTitle != null) {
    		Category category = getCategoryByTitle(categoryTitle);
	    	sessionFactory.getCurrentSession().delete(category);
	    	logger.info("Category deleted successfully, Category details="+category);
	        return true;
	} else {
		return false;
	}
   }

    /*
     * Retrieve all existing categories
     */

    @Override
    @SuppressWarnings("unchecked")
    public List<Category> getAllCategories() {
		Criteria criteria = sessionFactory.getCurrentSession().createCriteria(Category.class);
    	return criteria.list();
    }

    /*
     * Retrieve specific category from the database
     */

    @Override
    public Category getCategoryByTitle(String categoryTitle) {
    	if(categoryTitle != null) {
    		logger.info("Category loaded successfully, Category details="+categoryTitle);
    		return (Category) sessionFactory.getCurrentSession().get(Category.class, categoryTitle);
    		
    	} else {
    		return null;
    	}
    }
    
    @Override
    public List<Task> getAllTasks(String categoryTitle) {
    	if(categoryTitle != null) {
    		logger.info("Task loaded successfully, Task details="+categoryTitle);
    		Criteria criteria = sessionFactory.getCurrentSession().createCriteria(Category.class, categoryTitle);
        	return criteria.list();
    	} else {
    		return null;
    	}
    }
}
