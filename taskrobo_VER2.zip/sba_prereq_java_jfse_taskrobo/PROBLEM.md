**Problem Statement**

AbsoluteRobo is a start-up focused on human productivity. The company is building an innovative platform to redefine how human productivity can be increased with the help of technology.
As part of the system design, AbsoluteRobo have researched that in an eight-hour day, the average human is only productive for approximately three hours. 
The problem to solve is to increase the average productive hour of a human by 60%.


**Proposed Solution**

As part of the AbsoluteRobo platform, TaskRobo will be a Web application that allows a user to manage daily tasks.
For the initial release, TaskRobo will come with the basic management features to help view and manage tasks of a day. A user will be able to view pending tasks, add new tasks, and mark the status of a task. 

**Milestones**
Milestone 1: SBA: Pre-req Java Jr-FSE TaskRobo (Approx. 5 hours)

    • Step 1: Manage dependencies for the project 
    • Step 2: Implement custom auto configuration for H2 database
    • Step 3: Build the task planner MVC application.
    • Step 4: Implement custom exception handling in all modules 
    • Step 5: Implement javascript methods

    
 #### Complete the following classes as per the requirement.

**class Task**
 
 Define the following properties.Properties should be private.
 
        -taskId : int
        -taskTitle : String
        -taskContent : String
        -taskStatus :String
        -category: Category
        
 Define parameterized constructor to initialize all the properties
 
 Define Getter and Setter for all the properties
 
 Override the toString() method to display Task details
 
 
 **class Category**
 
 Define the following properties.Properties should be private.
        
        -categoryTitle : String
        -tasks :List<Task>
        
 Define parameterized constructor to initialize all the properties
 
 Define Getter and Setter for all the properties
 
 Override the toString() method to display Category details


**class TaskDaoImpl**
 
 Define the below methods :
 
         +saveTask(Task task) : boolean
         +deleteTask(int taskId) : boolean
         +getAllTasks() : List<Task>
         +getTaskById(int taskId) : Task
         +updateTask(Task task) : boolean
 
 **class CategoryDaoImpl**
 
 Define the below methods :
 
         +saveCategory(Category category) : boolean
         +deleteCategory(String categoryTitle) : boolean
         +getAllcategories() : List<Category>
         +getCategoryByTitle(String categoryTitle) : Category
         
        
 **class TaskServiceImpl**
 
 Define the following methods :
 
         +saveTask(Task task) throws TaskAlreadyExistException : boolean
         +updateTask(Task task) throws TaskDoesNotExistException : boolean
         +getTaskById(int taskId) throws TaskDoesNotExistException : Task
         +getAllTasks() : List<Task>
         +deleteTask(int taskId) throws TaskDoesNotExistException : boolean
         
         
 **class CategoryServiceImpl**
 
 Define the following methods :
 
         +saveCategory(Category category) throws CategoryAlreadyExistException : boolean
         +getCategoryByTitle(String categoryTitle) throws CategoryDoesNotExistException : Category
         +getAllTasks(String categoryTitle) throws CategoryDoesNotExistException : List<Task>
         +getAllcategories() : List<Category>
         +deleteTask(String categoryTitle) throws TaskDoesNotExistException : Boolean
          
 **src/main/webapp/resources/taskrobo/js/index.js**
 
 Implement the following methods:
  
         +validId()
         +validTitle()
         +validateContent()
         +validateStatus()
         +displayAddTask()
         +validateCategoryTitle()
            
 **Run javascript tests** 
    
  - Navigate to `src/main/webapp/resources/taskrobo/test/`
  - Run `npm install` and `npm test`  to run the test cases
  *Install the latest version of node*  
          
 ## Instructions
 - Avoid printing unnecessary values other than expected output as given in sample
 - Take care of whitespace/trailing whitespace
 - Do not change the provided class/method names unless instructed
 - Follow best practices while coding
  