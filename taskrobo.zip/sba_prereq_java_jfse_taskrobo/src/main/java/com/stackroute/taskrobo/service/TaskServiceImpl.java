package com.stackroute.taskrobo.service;

import com.stackroute.taskrobo.dao.TaskDao;
import com.stackroute.taskrobo.exception.TaskAlreadyExistException;
import com.stackroute.taskrobo.exception.TaskDoesNotExistException;
import com.stackroute.taskrobo.model.Task;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import java.util.List;

/*
 * Service classes are used here to implement additional business logic/validation
 * This class has to be annotated with @Service annotation.
 */

@PropertySource("classpath:application.properties")
public class TaskServiceImpl implements TaskService {
    private TaskDao taskDAO;
    /* Do not hardcode exception message. Get it from application.properties using environment variables. */
    private Environment environment;


    public TaskServiceImpl() {
    }

    /*
     * Constructor based Autowiring should be implemented for the TaskDao and
     * Environment.Please note that we should not create any object using the new
     * keyword.
     */

    /*
     * This method should be used to save a new task.
     */
    @Override
    public boolean saveTask(Task task) throws TaskAlreadyExistException {
        return false;
    }

    /*
     * This method should be used to update a existing task.
     */

    @Override
    public boolean updateTask(Task task) throws TaskDoesNotExistException {
        return false;
    }


    /*
     * This method should be used to get a task by taskId.
     */

    @Override
    public Task getTaskById(int taskId) throws TaskDoesNotExistException {
        return null;
    }

    /*
     * This method should be used to get all the tasks.
     */

    @Override
    public List<Task> getAllTasks() {
        return null;
    }


    /* This method should be used to delete an existing task. */
    @Override
    public boolean deleteTask(int taskId) throws TaskDoesNotExistException {
        return false;
    }
}
