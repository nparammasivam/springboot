package com.stackroute.taskrobo.dao;

import com.stackroute.taskrobo.model.Task;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

import javax.transaction.Transactional;

/*
 * This class is implementing the TaskDao interface. This class has to be annotated with following annotation
 * @Repository - is an annotation that marks the specific class as a Data Access Object, thus
 * 				 clarifying it's role.
 * @Transactional - The transactional annotation itself defines the scope of a single database
 * 					transaction. The database transaction happens inside the scope of a persistence
 * 					context.
 *
 */

@Repository
@Transactional
public class TaskDaoImpl implements TaskDao {
	@Autowired
    private SessionFactory sessionFactory;

    public TaskDaoImpl() {
    }

    /*
     * Constructor based Autowiring should be implemented for the SessionFactory
     * Please note that we should not create any object using the new
     * keyword.
     */

    /*
     * Save the task in the database(task) table.
     */

    @Override
    public boolean saveTask(Task task) {
    	if(task != null) {
    		return (boolean) sessionFactory.getCurrentSession().save(task);    		
    	} else  {
    		return false;
    	}
    }

    /*
     * Remove the task from the database(task) table.
     */

    @Override
    public boolean deleteTask(int taskId) {
    	if(taskId!=0) {
		    	Task task = getTaskById(taskId);
		    	sessionFactory.getCurrentSession().delete(task);
		        return true;
    	} else {
    		return false;
    	}
    }

    /*
     * Retrieve all existing tasks
     */

    @Override
    @SuppressWarnings("unchecked")
    public List<Task> getAllTasks() {
    	Criteria criteria = sessionFactory.getCurrentSession().createCriteria(Task.class);
    	return criteria.list();
    }

    /*
     * Retrieve specific task from the database
     */

    @Override
    public Task getTaskById(int taskId) {
    	if(taskId > 0) {
    		return (Task) sessionFactory.getCurrentSession().get(Task.class, taskId);
    	} else {
    		return null;
    	}
    	
    }

    /* Update existing task */

    @Override
    public boolean updateTask(Task task) {
    	if(task != null) {
    		sessionFactory.getCurrentSession().merge(task);
    		return true;
    	} else  {
    		return false;
    	}
    }

}
