package com.stackroute.taskrobo.service;

import com.stackroute.taskrobo.dao.CategoryDao;
import com.stackroute.taskrobo.exception.CategoryAlreadyExistException;
import com.stackroute.taskrobo.exception.CategoryDoesNotExistException;
import com.stackroute.taskrobo.model.Category;
import com.stackroute.taskrobo.model.Task;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.util.List;

import javax.transaction.Transactional;

/*
 * Service classes are used here to implement additional business logic/validation
 * This class has to be annotated with @Service annotation.
 */


@Service
@Transactional
@PropertySource("classpath:application.properties")
public class CategoryServiceImpl implements CategoryService {
	
	@Autowired
    private CategoryDao categoryDao;
	
    /* Do not hardcode exception message. Get it from application.properties using environment variables. */
    private Environment environment;

    /*
     * Constructor based Autowiring should be implemented for the CategoryDao and
     * Environment.Please note that we should not create any object using the new
     * keyword.
     */


    /*
     * This method should be used to save a new category.
     */

    @Override
    public boolean saveCategory(Category category) throws CategoryAlreadyExistException {
    	
        return false;
    }

    /*
     * This method should be used to get a category by categoryTitle.
     */

    @Override
    public Category getCategoryByTitle(String categoryTitle) throws CategoryDoesNotExistException {
        return null;
    }

    /*
     * This method should be used to get all the tasks for particular Category.
     */
    @Override
    public List<Task> getAllTasks(String categoryTitle) throws CategoryDoesNotExistException {
        return null;
    }

    /*
     * This method should be used to get all the categories.
     */

    @Override
    public List<Category> getAllCategories() {
        return null;
    }

    /* This method should be used to delete an existing category. */

    @Override
    public boolean deleteCategory(String categoryTitle) throws CategoryDoesNotExistException {
        return false;
    }
}