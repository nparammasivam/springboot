
class Validator {
  constructor(color) {
    this.color = color;
  }
  //This method returns message if color is red
  getMessage() {
   return null;
  }
}


//This class inherits class Validator
class TitleValidator extends Validator {
  constructor(color) {
    super(color);
  }
  //Returns the message
  getMessage() {
  return null;
  }
}

//Write an arrow 'validId' function to check if the id is valid
validId = () => {

}



//Write a function to check if the taskTitle is valid
function validTitle() {

}

//This function checks if taskContent is not empty and length is not more 100 characters
function validateContent() {

}
//This function checks if taskStatus is not empty and length is not more 10 characters
function validateStatus() {

}


//This function checks if taskListTitle is not empty and length is not more 100 characters

function validateTaskListTitle() {

}
//This function use to display addTask div
function displayAddTask() {

}

module.exports = {
  validId,
  validTitle,
  Validator,
  TitleValidator,
  validateContent,
  validateStatus,
  displayAddTask,
  validateTaskListTitle
};
// You will get error - Uncaught ReferenceError: module is not defined
// while running this script on browser which you shall ignore
// as this is required for testing purposes and shall not hinder
// it's normal execution


