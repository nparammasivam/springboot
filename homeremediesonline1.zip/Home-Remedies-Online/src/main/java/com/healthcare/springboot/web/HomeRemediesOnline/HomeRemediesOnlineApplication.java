package com.healthcare.springboot.web.HomeRemediesOnline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomeRemediesOnlineApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomeRemediesOnlineApplication.class, args);
	}

}
