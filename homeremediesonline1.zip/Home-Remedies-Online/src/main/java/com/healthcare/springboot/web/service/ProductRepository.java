package com.healthcare.springboot.web.service;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.healthcare.springboot.web.model.Product;

public interface ProductRepository extends JpaRepository<Product, Integer>{
	List<Product> findByUser(String product);	
}
