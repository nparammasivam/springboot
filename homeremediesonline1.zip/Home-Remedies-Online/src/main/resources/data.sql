insert into PRODUCT
values (10001, 'Energy', 'Apple','Fruit','siva');
insert into PRODUCT
values (10002, 'Cold', 'Tulsi', 'Herb','siva');
insert into PRODUCT
values (10003, 'Throat Infection', 'Athimathuram','Herb', 'siva');

insert into PRODUCT
values (10004, 'Energy', 'Orange','Fruit','user');
insert into PRODUCT
values (10005, 'Cold', 'Thuthuvalai', 'Herb','user');
insert into PRODUCT
values (10006, 'Throat Infection', 'Dry Ginger','Herb', 'user');